1: Compile with javac *.java
2: Main-method is in Main.java
3: Nothing in particular
4: Kinda weird that I look up words by calling on the root as well as including the root as a parameter.
5: Everything works as far as I understood the assignment.
6: Looked up plenty of things on stackoverflow.